int	ft_isgraph(int c)
{
	if (c >= '!' && c <= '~')
		return (1);
	return (0);
}
